#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <iostream>
#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel, vers;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> vers >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem - not attempted
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// Read and return the system memory utilization
float LinuxParser::MemoryUtilization() { 
  float total_memory, free_memory;
  float free_fraction, util_fraction;
  string x,y,z,line;
  std::ifstream flstream(kProcDirectory + kMeminfoFilename);
  if (flstream.is_open()) {
    while (std::getline(flstream, line)) {
      std::istringstream linestream(line);
      while (linestream >> x >> y >> z) {
        if (x == "MemTotal:") {
          total_memory = stoi(y);
        }
        if (x == "MemFree:") {
          free_memory = stoi(y);
        }
      }
    }
  }
  free_fraction = free_memory / total_memory;
  util_fraction = 1 - free_fraction;
  return util_fraction; 
}

// Read and return the system uptime
long LinuxParser::SysUpTime() { 
  long uptime;
  string x,y,line;
  std::ifstream flstream(kProcDirectory + kUptimeFilename);
  if (flstream.is_open()) {
    std::getline(flstream, line);
    std::istringstream linestream(line);
    linestream >> x >> y;
    uptime = std::stol(x);
  }
  return uptime;
}

// TODO: Read and return the number of jiffies for the system - not reqd for current implementation
long LinuxParser::Jiffies() { return 0; }

// Read and return the number of active jiffies for a PID
long LinuxParser::ActiveJiffies(int pid) { 
  string jiffy, line, garbage;
  long jiffies = 0;;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    for(int i=0; i<21; i++) {
      if(i == 14 || i == 15 || i == 16 || i == 17)
      {
        linestream >> jiffy;
        jiffies += stol(jiffy);
      }
      else
        linestream >> garbage;
    }
  }
  return jiffies; 
}

// TODO: Read and return the number of active jiffies for the system - not reqd for current implementation
long LinuxParser::ActiveJiffies() { return 0; }

// TODO: Read and return the number of idle jiffies for the system - not reqd for current implementation
long LinuxParser::IdleJiffies() { return 0; }

// TODO: Read and return CPU utilization - not reqd for current implementation
vector<string> LinuxParser::CpuUtilization() { return {}; }

// Read and return the total number of processes
int LinuxParser::TotalProcesses() { 
  int total_process;
  string x,y,line;
  std::ifstream flstream(kProcDirectory + kStatFilename);
  if (flstream.is_open()) {
    while (std::getline(flstream, line)) {
      std::istringstream linestream(line);
      while (linestream >> x >> y) {
        if (x == "processes") {
          total_process = stoi(y);
        }
      }
    }
  }
  return total_process; 
}

// Read and return the number of running processes
int LinuxParser::RunningProcesses() { 
  int n_alive_processes;
  string x,y,line;
  std::ifstream flstream(kProcDirectory + kStatFilename);
  if (flstream.is_open()) {
    while (std::getline(flstream, line)) {
      std::istringstream linestream(line);
      while (linestream >> x >> y) {
        if (x == "procs_running") {
          n_alive_processes = stoi(y);
        }
      }
    }
  }
  return n_alive_processes; 
}

// Read and return the command associated with a process
string LinuxParser::Command(int pid) { 
  std::string command;
  std::ifstream stream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  std::getline(stream,command);
  return command; 
}

// Read and return the memory used by a process
string LinuxParser::Ram(int pid) { 
  std::string ram, line, x;
  int ram_int;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatusFilename);
  if (stream.is_open()) {
    while (std::getline(stream, line)) {
      std::istringstream linestream(line);
      while (linestream >> x >> ram) {
        if (x == "VmSize:") {
          ram_int = stoi(ram);
        }
      }
    }
  }
  ram_int = ram_int * 0.001; // convert to MB
  ram = to_string(ram_int);
  return ram; 
  }

// Read and return the user ID associated with a process
string LinuxParser::Uid(int pid) { 
  string uid, line, key, x;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatusFilename);
  if (stream.is_open()) {
    while (std::getline(stream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> x){
        if (key == "Uid:"){
          uid = x;
        }
      }
    }
  }
  return uid; 
}

// Read and return the user associated with a process
string LinuxParser::User(int pid) { 
  string user, line, garbage, uid, x;
  std::ifstream stream(kPasswordPath);
  if (stream.is_open()) {
    while (std::getline(stream, line)) {
      std::replace(line.begin(), line.end(), ':', ' ');
      std::istringstream linestream(line);
      while (linestream >> x >> garbage >> uid){
        if (uid == Uid(pid)){
          user = x;
        }
      }
    }
  }
  return user; 
}

// Read and return the uptime of a process
long LinuxParser::UpTime(int pid) { 
  long uptime = 0;
  std::string up_since, line, garbage;
  vector<std::string> x;
  long clockticks = 0;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    for(int i=0; i<21; i++) {
      linestream >> garbage;
    }
    linestream >> up_since;
    clockticks = std::stol(up_since);
  }
  uptime = clockticks / sysconf(_SC_CLK_TCK);
  return uptime; 
}