#include <string>
#include <unistd.h>
#include <iostream>
#include <regex>
#include <fstream>
#include "processor.h"

// Return the aggregate CPU utilization
float Processor::Utilization() { 
    float idle, non_idle, total;
    std::string line,a,b,c,d,e,f,g,h,i,j,k;
    std::ifstream stream("/proc/stat");
    if (stream.is_open()) {
        while (std::getline(stream, line)) {
        std::istringstream linestream(line);
        while (linestream >> a >> b >> c >> d >> e >> f >> g >> h >> i >> j >> k) {
            if (a == "cpu") {
            idle = stoi(e) + stoi(f);
            non_idle = stoi(b) + stoi(c) + stoi(d) + stoi(g) + stoi(h) + stoi(i); 
            }
        }
    }}
    total = idle + non_idle;
    utilization_ = 1 - (idle/total);
    return utilization_; 
}

// Return the instantaneous CPU Utilization (polled 100ms apart)
float Processor::InstantUtilization(){
    float idle, non_idle, total;             //live poll results
    float previdle, prevnon_idle, prevtotal; //previous poll results
    float didle, dtotal;                     //differential results
    std::string line,a,b,c,d,e,f,g,h,i,j,k;
    std::ifstream stream("/proc/stat");
    if (stream.is_open()) {
        while (std::getline(stream, line)) {
            std::istringstream linestream(line);
            while (linestream >> a >> b >> c >> d >> e >> f >> g >> h >> i >> j >> k) {
                if (a == "cpu") {
                    previdle = stoi(e) + stoi(f);
                    prevnon_idle = stoi(b) + stoi(c) + stoi(d) + stoi(g) + stoi(h) + stoi(i); 
                }
            }
        }
    }
    prevtotal = previdle + prevnon_idle;
    
    usleep(100000); // sleep for 100ms before polling the stats again
    
    std::ifstream astream("/proc/stat");
    if (stream.is_open()) {
        while (std::getline(astream, line)) {
            std::istringstream alinestream(line);
            while (alinestream >> a >> b >> c >> d >> e >> f >> g >> h >> i >> j >> k) {
                if (a == "cpu") {
                    idle = stoi(e) + stoi(f);
                    non_idle = stoi(b) + stoi(c) + stoi(d) + stoi(g) + stoi(h) + stoi(i); 
                }
            }
        }
    }
    total = idle + non_idle;
    dtotal = total - prevtotal; // differential of total
    didle = idle - previdle;    // differential of idle
    inst_utilization_ = 1 - (didle/dtotal);
    return inst_utilization_; 
}