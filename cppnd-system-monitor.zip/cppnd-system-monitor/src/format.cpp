#include <string>
#include <cmath>
#include "format.h"

using std::string;
using std::to_string;
// Helper function to change the format of reported time
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
string Format::ElapsedTime(long int original_seconds)
{
    string time;
    int n = round(original_seconds);
    int second = (n % 3600) % 60;
    int minute = (n % 3600) / 60;
    int hour = n / 3600; // calculating hours
    time = to_string(hour)+":"+to_string(minute)+":"+to_string(second);
    return time;
}