#ifndef PROCESSOR_H
#define PROCESSOR_H

class Processor {
 public:
  float Utilization();
  float InstantUtilization(); // attempting Bonus objective to calculate instantaneous utilization

 private:
 float utilization_;
 float inst_utilization_;
};

#endif